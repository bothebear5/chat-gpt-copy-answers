async function exportToNotion(notionContent, notionAuth) {
    const req = new XMLHttpRequest();
    const baseUrl = "https://jpwv43ppkip63xz6he4gy3zn6a0ysndz.lambda-url.eu-west-2.on.aws/notion";

    req.open("POST", baseUrl, true);
    req.setRequestHeader("Content-type", "application/json");
    req.setRequestHeader("Authorization", `Bearer ${notionAuth}`)
    req.send(JSON.stringify(notionContent));

    req.onreadystatechange = function () {
        if (this.readyState === XMLHttpRequest.DONE) {
            if (this.status === 200) {
                let response = JSON.parse(this.responseText)
                window.open(response.url)
            }
            else {
                alert(this.responseText)
            }
        }
    }
}

window.addEventListener("message", async (event) => {
    if (event.data.type && (event.data.type === "NOTION_AUTH_FLOW")) {
        await chrome.storage.sync.set({ "notion_auth_2": event.data.code })
        var notion = await chrome.storage.local.get(["notion_content"])
        if (notion && notion.notion_content) {
            chrome.storage.local.remove("notion_content")
            await exportToNotion(notion.notion_content, event.data.code)
        }
    }
}, false);