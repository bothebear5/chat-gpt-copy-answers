
async function getTab() {
  let tabs = await chrome.tabs.query({ active: true, currentWindow: true  })
  return tabs[0]
}

function extractConversationHtml(textContent) {
  let result = []
  for (let node of document.querySelectorAll("div.w-full div.text-base")) {
    let robotMarkdown = node.querySelector("div.markdown")
    if (robotMarkdown) {
      result.push({
        "body": textContent ? robotMarkdown.textContent : robotMarkdown.getInnerHTML()
      })
    }
    else {
      
    }
  }
  if (result.length) {
    return {
      "title": document.querySelector("nav a.bg-gray-800 div")?.textContent || "No title",
      "nodes": result
    }
  }
  return {};
}

async function getPageContent(textContent) {
  let tab = await getTab()
  let injectionResults = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: extractConversationHtml,
    args: [textContent || false]
  })
  if (injectionResults == null || injectionResults.length == 0 || !injectionResults[0].result) {
    return null;
  }
  return injectionResults[0].result;
}

function __track(event) {
  mixpanel.init('9887abec8a29c6829e14d2386d7da554', { api_host: "https://api.mixpanel.com" });
  mixpanel.track(event)
}
function __start(button, event) {
  __track(event)
  button.classList.add("onclic");
  button.setAttribute("disabled", "");
}

function __terminate(button) {
  button.classList.remove("onclic")
  button.removeAttribute("disabled")
}

function __end(button) {
  setTimeout(function () {
    button.classList.remove("onclic")
    button.classList.add("ondone");
  }, 500);

  setTimeout(function () {
    button.classList.remove("ondone")
    button.removeAttribute("disabled")
  }, 1500);
}



let copyButton = document.getElementById("copy");
let exportToNotionButton = document.getElementById("export_to_notion");
let downloadAsImages = document.getElementById("download_as_images");
// let tweetButton = document.getElementById("tweet");



async function copyToClipBoard(e) {
  e.preventDefault();

  __start(copyButton, "copy")

  let pageContent = await getPageContent(true)

  if (!pageContent) {
    alert("No conversation to copy, please make sure you on the ChatGPT site and have selected a conversation")
    __terminate(copyButton)
    return
  }

  let content = pageContent.title;
  content += "\n"
  for (const { type, body } of pageContent.nodes) {
	content += "\n" + body + "\n"
  }

  navigator.clipboard.writeText(content);

  __end(copyButton)
}

async function exportToNotion(e) {
  if (e) {
    e.preventDefault();
  }

  var notionAuth = await chrome.storage.sync.get(["notion_auth_2"])
  let pageContent = await getPageContent()
  if (notionAuth && notionAuth.notion_auth_2) {
    __start(exportToNotionButton, "export_to_notion")

    if (!pageContent) {
      alert("No conversation to export, please make sure you on the ChatGPT site and have selected a conversation")
      __terminate(exportToNotionButton)
      return
    }

    const req = new XMLHttpRequest();
    const baseUrl = "https://jpwv43ppkip63xz6he4gy3zn6a0ysndz.lambda-url.eu-west-2.on.aws/notion";

    req.open("POST", baseUrl, true);
    req.setRequestHeader("Content-type", "application/json");
    req.setRequestHeader("Authorization", `Bearer ${notionAuth.notion_auth_2}`)
    req.send(JSON.stringify(pageContent));

    req.onreadystatechange = function () {
      if (this.readyState === XMLHttpRequest.DONE) {
        __end(exportToNotionButton)
        if (this.status === 200) {
          let response = JSON.parse(this.responseText)
          window.open(response.url)
        }
        else {
          alert(this.responseText)
        }
      }
    }
  }
  else {
    chrome.storage.local.set({ "notion_content": pageContent })
    __track("export_to_notion_auth_flow")
    window.open(encodeURI("https://api.notion.com/v1/oauth/authorize?client_id=6b58448e-f0e4-4f46-a759-98d639868de8&response_type=code"))
  }
}

function uuidv4() {
  return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
    (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
  );
}

async function downloadImages(e) {
  if (e) {
    e.preventDefault();
  }
  __start(downloadAsImages, "downloadImages")
  let pageContent = await getPageContent()
  if (!pageContent) {
    alert("No conversation to download as images, please make sure you on the ChatGPT site and have selected a conversation")
    __terminate(downloadAsImages)
    return
  }
  const id = uuidv4()
  chrome.storage.local.set({ [id]: pageContent })
  __end(downloadAsImages)
  setTimeout(function () {
    window.open(encodeURI(`https://gptsave.xyz/images?id=${id}`))
  }, 500)
}


copyButton.addEventListener("click", copyToClipBoard, false);
exportToNotionButton.addEventListener("click", exportToNotion, false);
downloadAsImages.addEventListener("click", downloadImages, false);


(function () {
  var ga = document.createElement('script');
  ga.type = 'text/javascript';
  ga.async = true;
  ga.src = chrome.runtime.getURL('/thirdparty/mixpanel.js');
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(ga, s);

})();

