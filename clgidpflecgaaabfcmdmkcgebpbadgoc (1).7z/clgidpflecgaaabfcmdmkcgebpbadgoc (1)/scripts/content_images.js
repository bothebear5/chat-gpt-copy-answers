window.addEventListener("message", async (event) => {
    if (event.data.type && (event.data.type === "IMAGES_FLOW_STEP_1")) {
        var pageContent = await chrome.storage.local.get([event.data.id])
        if (pageContent && pageContent[event.data.id]) {
            window.postMessage({ content: pageContent[event.data.id], type: "IMAGES_FLOW_STEP_2" }, "*");
        }
        else {
            alert("Content not found")
        }
    }
}, false);